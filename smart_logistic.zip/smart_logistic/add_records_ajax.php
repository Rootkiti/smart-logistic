<?php

  require_once('dbconn.php');
  $product  = trim($_POST["product"]);
  $Quantity = trim($_POST["Quantity"]);
  $Type = trim($_POST["Type"]);
  $date = trim($_POST["date"]);
  $item_owner  = trim($_POST["item_owner"]);


  // prepare sql and bind parameters
  $product_stmt = $dbconn->prepare("SELECT Quantity , Type from invetory 
                                     where Item_name = :product and item_owner = :item_owner");
  $product_stmt->bindParam(':product', $product);
  $product_stmt->bindParam(':item_owner', $item_owner);

  // fetch a row
  $product_stmt->execute();
  $product_data = $product_stmt->fetch(PDO::FETCH_ASSOC);

  if($product_data['Type'] == $Type)
  {
    

   $qunt = $product_data['Quantity']; 
  

    $updated_quantity = $qunt + $Quantity;

    $update_stmt = $dbconn->prepare("UPDATE invetory set Quantity = :updated_quantity 
                                     where Item_name = :product and item_owner = :item_owner");
    $update_stmt->bindParam(':updated_quantity', $updated_quantity);
    $update_stmt->bindParam(':product', $product);
    $update_stmt->bindParam(':item_owner', $item_owner);

    // insert a row
    if($update_stmt->execute()){
        $result =1;
    }
    
    echo $result;
    $dbconn = null;
  }
  else
{
  
// // prepare sql and bind parameters
// $stmt = $dbconn->prepare("INSERT INTO invetory(Item_name, Quantity, Type, e_date,item_owner)
//                             VALUES (:product, :Quantity, :Type, :date, :item_owner)");
// $stmt->bindParam(':product', $product);
// $stmt->bindParam(':Quantity', $Quantity);
// $stmt->bindParam(':Type', $Type);
// $stmt->bindParam(':date', $date);
// $stmt->bindParam(':item_owner', $item_owner);

// // insert a row
// if($stmt->execute()){
//     $result =1;
// }

// echo $result;
// $dbconn = null;
}

