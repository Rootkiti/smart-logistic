<?php
include_once('dbconn.php');


  $prison  = trim($_POST["prison_id"]);
  $dpt  = trim($_POST["dpt_name"]);
  $dscr = trim($_POST["description"]);

// prepare sql and bind parameters
    $stmt = $dbconn->prepare("INSERT INTO departments(name, description, prison)
                               VALUES (:dpt, :dscr, :prison)");
    $stmt->bindParam(':dpt', $dpt);
    $stmt->bindParam(':dscr', $dscr);
    $stmt->bindParam(':prison', $prison);


    // insert a row
    if($stmt->execute()){
      $result =1;
    }

        $result = 1;
        echo $result;
       $dbconn = null; 





?>

