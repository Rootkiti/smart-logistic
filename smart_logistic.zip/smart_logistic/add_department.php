<?php session_start();
include_once('dbconn.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{
    $userid = $_SESSION['id'];
    $prison = $_SESSION['prison'];
?>

<!DOCTYPE html>
<html>
<head>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Add Department| Smart loigistic management information system</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

    
<style>
.container{
  margin: 20px auto;
}
h2 {
  text-align: center;
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}

body{
  font-family:Arial, Helvetica, sans-serif;
  font-size:13px;
}
.success, .error{
  border: 1px solid;
  margin: 10px 0px;
  padding:15px 10px 15px 50px;
  background-repeat: no-repeat;
  background-position: 10px center;
}

.success {
  color: #4F8A10;
  background-color: #DFF2BF;
  background-image:url('success.png');
  display: none;
}
.error {
  display: none;
  color: #D8000C;
  background-color: #FFBABA;
  background-image: url('error.png');
}
</style>
</head>
<body  class="sb-nav-fixed">
<?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
  <div class="container">
    
    <div class="success"></div>
    <div class="error"></div>
    <h2>Add / Edit Department</h2>
    <form >
      <center>
      <table class="table table-bordered table-striped w-50">
        <tr>
          
         <input type="hidden"  id ="dpt_id" value='' />
         <input type="hidden"  id ="prison_id" value='<?=$prison;?>' />

            <td style="text-align: center">
                <div class="form-floating mb-3 mb-md-0">
                    <input class="form-control" id="dpt_name" type="text" placeholder="Department Name" 
                           title="Enter Department Name" required/>
                    <label for="inputPassword">Department Name</label>
                </div>
          </td>
        </tr>
        <tr> 
            <td style="text-align: center; height: 20px;">
                <div class="form-floating mb-3 mb-md-0">
                    <textarea  class="form-control" id="description" placeholder="Description" cols="30" 
                               rows="50" title="Enter what is caried out in this Department"></textarea>
                    <label for="inputFirstName">Description</label>
                </div>
           </td>
        </tr>
        <tr>   
        <td style="text-align: center">
          <input type='button'  class="btn btn-primary " id='saverecords' title="Save" value ='Add Records' />
        </td>
        
        </tr>
      </table>
      </center>
    </form>
    
    
   <!-- data table start -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Available Prisons
                </div>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                
      <thead>
      <tr>
        <th>#</th>
        <th>Department Name</th>
        <th>Description</th>
        <th>Action</th>
      </tr>
      </thead>
      <tbody>
  <?php
  /* FetchAll foreach with edit and delete using Ajax */
  
$sth = $dbconn->prepare("SELECT * FROM departments where status = 1 and prison = $prison order by name asc");
$sth->execute();
/* Fetch all of rows in the result set */
$result = $sth->fetchAll();
  if($sth->rowCount()):
    $cts = 1;
   foreach($result as $row){ ?>
     <tr>
       <td><?php echo $cts; ?></td>
       <td><?php echo $row['name']; ?></td>
       <td><?php echo $row['description']; ?></td>
       <td><a data-pid = <?php echo $row['id']; ?> class='editbtn' href= 'javascript:void(0)'>
                <li class="fas fa-edit" title="edit"></li>
            </a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a class='delbtn' data-pid=<?php echo $row['id']; ?> href='javascript:void(0)'>
                <li class="fa fa-trash" title="send in trash" ></li>
            </a>
        </td>
     </tr>
   <?php $cts ++;}  ?>
  <?php endif;  ?>
  </tbody>
  </table>
  
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            
          </div>
          <!-- /.col -->
          
        </div>
        <!-- /.row -->
        
      </div>
      <!-- /.container-fluid -->
    </section>
    <div class=" container"style="margin-top: 50;"> 
    <center>
      <div style="font-weight: 800; margin-bottom: 20px;">
           Trashed Contents Will Appear Here!
      </div>
    </center>
        <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                Trash
                </div>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                
      <thead>
      <tr>
        <th>#</th>
        <th>Prison Name</th>
        <th>Description</th>
        <th>Action</th>
      </tr>
      </thead>
      <tbody>
  <?php
  /* FetchAll foreach with edit and delete using Ajax */
  
$sth = $dbconn->prepare("SELECT * FROM departments where status = 0 and prison = $prison order by name asc");
$sth->execute();
/* Fetch all of rows in the result set */
$result = $sth->fetchAll();
  if($sth->rowCount()):
    $cts = 1;
   foreach($result as $row){ ?>
     <tr>
       <td><?php echo $cts; ?></td>
       <td><?php echo $row['name']; ?></td>
       <td><?php echo $row['description']; ?></td>
       <td><a data-pid = <?php echo $row['id']; ?> class='rstbtn' href= 'javascript:void(0)'>
           <li class="fas fa-recycle" title="Restore"></li></a>&nbsp;&nbsp;|&nbsp;&nbsp;
       <a class='forever' data-pid=<?php echo $row['id']; ?> href='javascript:void(0)'>
          <li class="fa fa-trash" title="Delete Parmernent ?"></li></a></td>
     </tr>
   <?php $cts ++;}  ?>
  <?php endif;  ?>
  </tbody>
  </table>
  
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            
          </div>
          <!-- /.col -->
          
        </div>
        <!-- /.row -->
        
      </div>
      <!-- /.container-fluid -->
    </section>
</div>
    <!-- /.content -->
  </div>
  <!-- data table end -->
  </div>
        
  
  
</div>
</div>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- DataTables  & Plugins -->
        <script src="plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="plugins/jszip/jszip.min.js"></script>
        <script src="plugins/pdfmake/pdfmake.min.js"></script>
        <script src="plugins/pdfmake/vfs_fonts.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
        <!-- AdminLTE App -->
        <script src="dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <!-- <script src="../dist/js/demo.js"></script> -->
        <!-- Page specific script -->
        <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
        </script>
  <script>
    $(function(){

      /* trash button ajax call */
      $('.delbtn').on( 'click', function(){
        if(confirm('This action will send this record in trash. Are you sure?')){
          var pid = $(this).data('pid');
          $.post( "trash_department.php", { pid: pid })
          .done(function( data ) {
            if(data > 0){
              $('.success').show(500).html("Record sent in trash successfully.").delay(500).fadeOut(6000);
            }else{
              $('.error').show(500).html("Record could not be trashed. Please try again.").delay(500).fadeOut(6000);;
            }
            setTimeout(function(){
                window.location.reload(1);
            }, 500);
          });
        }
      });
        
      
     /* Edit button ajax call */
      $('.editbtn').on( 'click', function(){
        var pid = $(this).data('pid');
        $.get("edit_department.php", { pid: pid })
            .done(function( product ) {
              data = $.parseJSON(product);

              if(data){
                $('#dpt_id').val(data.id);
                $('#dpt_name').val(data.name);
                $('#description').val(data.description);
                $("#saverecords").val('Save Changes');
                
            }

            // alert(pid);
            
          });
          
      });

      /* Edit button ajax call */
       $('#saverecords').on( 'click', function(){
           var dpt_id  = $('#dpt_id').val();
           var prison_id  = $('#prison_id').val();
           var dpt_name = $('#dpt_name').val();
           var description   = $('#description').val();
           if(!dpt_name || !description){
             $('.error').show(500).html("All fields are required.").delay(500).fadeOut(3000);
           }else{
                if(dpt_id){
                var url = 'edit_department.php';
              }else{
                var url = 'add_department_ajax.php';
              }
                $.post( url, {dpt_id:dpt_id, prison_id:prison_id, dpt_name:dpt_name, description:description})
               .done(function( data ) {
                 if(data > 0){
                   $('.success').show(500).html("Record saved successfully.").delay(2000).fadeOut(1000);
                 }else{
                   $('.error').show(500).html("Record could not be saved. Please try again.").delay(500).fadeOut(1000);
                 }
                 $("#saverecords").val('Add Records');
                 setTimeout(function(){
                     window.location.reload(1);
                 }, 1000);
             });
          }
       });

      /* restore button ajax call */
      $('.rstbtn').on( 'click', function(){
        if(confirm('This action will restore this record. Are you sure?')){
          var pid = $(this).data('pid');
          $.post( "restore_department.php", { pid: pid})
          .done(function( data ) {
            if(data > 0){
              $('.success').show(500).html("Record Restored successfully.").delay(500).fadeOut(6000);
            }else{
              $('.error').show(500).html("Record could not be Restored. Please try again.").delay(500).fadeOut(6000);;
            }
            setTimeout(function(){
                window.location.reload(1);
            }, 500);
          });
        }
      });

      /* delete forver ajax call */
      $('.forever').on( 'click', function(){
        if(confirm('Delete This Record Permanently. Are you sure?')){
          var pid = $(this).data('pid');
          var action = "forever";
          $.post( "delete_department.php", { pid: pid, action:action })
          .done(function( data ) {
            if(data > 0){
              $('.success').show(500).html("Record Deleted Permanently.").delay(500).fadeOut(6000);
            }else{
              $('.error').show(500).html("Record could not be Deleted. Please try again.").delay(500).fadeOut(6000);;
            }
            setTimeout(function(){
                window.location.reload(1);
            }, 500);
          });
        }
      });
    });
 </script>
</body>
</html>
<?php } ?>