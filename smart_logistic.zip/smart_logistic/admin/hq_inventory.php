<?php session_start();
include_once('dbconn.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
    
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Inventory| Smart loigistic management information system</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

    
<style>
.container{
  margin: 20px auto;
}
h2 {
  text-align: center;
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}

body{
  font-family:Arial, Helvetica, sans-serif;
  font-size:13px;
}
.success, .error{
  border: 1px solid;
  margin: 10px 0px;
  padding:15px 10px 15px 50px;
  background-repeat: no-repeat;
  background-position: 10px center;
}

.success {
  color: #4F8A10;
  background-color: #DFF2BF;
  background-image:url('success.png');
  display: none;
}
.error {
  display: none;
  color: #D8000C;
  background-color: #FFBABA;
  background-image: url('error.png');
}
</style>
</head>
<body class="sb-nav-fixed">
<?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
         <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
  <div class="container">
   
    <h2>Inventory smart logistic </h2>
    
    <div class="success"></div>
    <div class="error"></div>
    <h2>Manage Inventory</h2>
    <form>
       <table class="table table-bordered table-striped">
        <tr>
        
            <input type="hidden" id ='item_id' value='' />
        
        <td style="text-align: center">    
            <div class="form-floating mb-3 mb-md-0">
              <select   id="Item_name"  class="form-control">
              <option value="#">Product</option>
                    <?php
                    /* FetchAll foreach with edit and delete using Ajax */
                    $items = $dbconn->prepare("SELECT id, name FROM item  where status = 1 order by name asc");
                    $items->execute();
                  /* Fetch all of rows in the result set */
                  $results = $items->fetchAll();
                    
                    foreach($results as $row){ ?>
                    
                          
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                        

                    <?php }  ?>
                    
              </select>
              
            </div>
        </td>  
        <td style="text-align: center">  
            <div class="form-floating mb-3 mb-md-0">
             <input type='number' pattern="[0-9]" class="form-control" id='Quantity' placeholder="Quantity" required />
             <label for="">Quantity</label>
          </div>
        </td>
        <td style="text-align: center">  
          <div class="form-floating mb-3 mb-md-0">
            <select  class="form-control" id="Type">
              <option value="#">Type</option>
                    <?php
                    /* FetchAll foreach with edit and delete using Ajax */
                    $items = $dbconn->prepare("SELECT type FROM item where status = 1 order by name asc");
                    $items->execute();
                  /* Fetch all of rows in the result set */
                  $results = $items->fetchAll();
                    
                    foreach($results as $row){ ?>
                    
                          
                        <option value="<?php echo $row['type']; ?>"><?php echo $row['type']; ?></option>
                        

                    <?php }  ?>
                    
              </select>
          </div>
        </td>
        <td style="text-align: center">  
          <div class="form-floating mb-3 mb-md-0">
              <input type='date' class="form-control" id='e_date'  placeholder="Entry Date" required />
              <label for="">Entry Date</label>
          </div>
        </td>
        
          <td style="text-align: center">  
          <div class="form-floating mb-3 mb-md-0">
             <input type='button' class="btn btn-primary" id='saverecords'  value ='Add Tems' />
          </div>
        </td>
        </tr>
      </table>
    </form>
    <!-- data table start -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    View Records
                </div>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
             <table id="example1" class="table table-bordered table-striped">
                
      <thead>
      <tr>
        <th>#</th>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Type</th>
        <th>Date</th>
        <th>Action</th>
      </tr>
      </thead>
      <tbody>
  <?php
  /* FetchAll foreach with edit and delete using Ajax */
  $sth = $dbconn->prepare("SELECT hq_stock.id as id, hq_stock.quantity as quantity,
                            hq_stock.type as type, hq_stock.date as date, item.name as item, item.unit as unit
                             FROM hq_stock, item where item.id=hq_stock.item order by id desc");
$sth->execute();
/* Fetch all of rows in the result set */
$result = $sth->fetchAll();
  if($sth->rowCount()):
    $a = 1;
   foreach($result as $row){ ?>
   
          <tr>
       <td><?php echo $a ?></td>
       <td><?php echo $row['item']; ?></td>
       <td><?php echo $row['quantity']; ?> <span><?php echo $row['unit']; ?></span></td>
       <td><?php echo $row['type']; ?></td>
       <td><?php echo $row['date']; ?></td>

       <td><a data-pid = <?php echo $row['id']; ?> class='editbtn' title="Edit Item" href= 'javascript:void(0)'>
       <li class="fa fa-edit"></li></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a class='delbtn'  data-pid=<?php echo $row['id']; ?>
        href='javascript:void(0)'><li class="fa fa-trash" title="Send In Trash"></li></a></td>
     </tr>
   <?php $a ++;}  ?>
  <?php endif;  ?>
  </tbody>

  </table>

  </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- data table end -->
  
  </div>
  
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <!-- jQuery -->
  <script src="../plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- DataTables  & ../Plugins -->
        <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="../plugins/jszip/jszip.min.js"></script>
        <script src="../plugins/pdfmake/pdfmake.min.js"></script>
        <script src="../plugins/pdfmake/vfs_fonts.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
        <!-- AdminLTE App -->
        <script src="../dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <!-- <script src="dist/js/demo.js"></script> -->
        <!-- Page specific script -->
        <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
        </script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      $('nav li').on('click', function () {  // we are letting the li bind to the event
        alert('Do you Real want to Close the stock');
      });
    });
  </script>
  <script>
    $(function(){
       
      
      /* Delete button ajax call */
      $('.delbtn').on( 'click', function(){
        if(confirm('This Date will delete this record. Are you sure?')){
          var pid = $(this).data('pid');
          $.post( "delete_ajax.php", { pid: pid })
          .done(function( data ) {
            if(data > 0){
              $('.success').show(500).html("Record deleted successfully.").delay(500).fadeOut(6000);
            }else{
              $('.error').show(500).html("Record could not be deleted. Please try again.").delay(500).fadeOut(6000);;
            }
            setTimeout(function(){
                window.location.reload(1);
            }, 500);
          });
        }
      });

     /* Edit button ajax call */
      $('.editbtn').on( 'click', function(){
          var pid = $(this).data('pid');
          var action = "getvalue";
          $.get( "getrecord_ajax.php", { id: pid, action:action })
            .done(function( product ) {
              data = $.parseJSON(product);

              if(data){
                $('#item_id').val(data.id);
                $('#Item_name').val(data.item);
                $('#Quantity').val(data.quantity);
                $('#Type').val(data.type);
                $('#e_date').val(data.date);
                $("#saverecords").val('Save Records');
            }
          });
      });

      /* Edit button ajax call */
       $('#saverecords').on( 'click', function(){
           var item_id = $('#item_id').val();
           var product = $('#Item_name').val();
           var Quantity = $('#Quantity').val();
           var Type = $('#Type').val();
           var date = $('#e_date').val();
           var action = "save";
           


           if(!product || !Quantity ||!date || !Type){
             $('.error').show(500).html("All fields are required.").delay(500).fadeOut(3000);
           }else{
                if(item_id){
                var url = 'edit_item.php';
              }else{
                var url = 'item_action.php';
              }
                $.post( url, {item_id:item_id, product:product, Quantity:Quantity, Type:Type, date:date, action:action})
               .done(function( data ) {
                 if(data > 0){
                   $('.success').show(500).html("Item saved successfully.").delay(500).fadeOut(1000);
                 }else{
                   $('.error').show(500).html("Item could not be saved. Please try again.").delay(500).fadeOut(1000);
                 }
                 $("#saverecords").val('Add Item');
                 setTimeout(function(){
                     window.location.reload(1);
                 }, 500);
             });
          }
       });
    });
 </script>
</body>
</html>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>



        <?php } ?>