<?php
  require_once('dbconn.php');
  $id = trim($_POST["prison_id"]);
  $prison_name  = trim($_POST["prison_name"]);
  $location    = trim($_POST["location"]);
// prepare sql and bind parameters
    $stmt = $dbconn->prepare("UPDATE prison set name = :prison_name, location = :location where id = :id");
    $stmt->bindParam(':prison_name', $prison_name);
    $stmt->bindParam(':location', $location);
    $stmt->bindParam(':id', $id);
   
    // insert a row
    if($stmt->execute()){
      $result =1;
    }
    echo $result;
    $dbconn = null;