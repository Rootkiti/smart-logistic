<?php
require_once('dbconn.php');

$result = 0;
if(isset($_POST['action']))
{
    $id = intval($_POST['pid']);
// ================= delete =================
if($_POST["action"]== "delete"){
  $stmt = $dbconn->prepare("UPDATE prison set status = 0 WHERE id = :id");
  $stmt->bindParam(':id', $id, PDO::PARAM_INT);
  if($stmt->execute()){
    $result = 1;
  }
  echo $result;
 $dbconn = null;
}
 
// ================= restore =================
if($_POST["action"]== "restore"){
    $stmt = $dbconn->prepare("UPDATE prison set status = 1 WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    if($stmt->execute()){
      $result = 1;
    }
    echo $result;
    $dbconn = null;
  }

  // ================= delete forever =================
if($_POST["action"]== "forever"){
    $stmt = $dbconn->prepare("DELETE FROM prison WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    if($stmt->execute()){
      $result = 1;
    }
    echo $result;
    $dbconn = null;
  }    
 
}