<?php
  require_once('dbconn.php');
  $id = trim($_POST["item_id"]);
  $item_name  = trim($_POST["product"]);
  $type    = trim($_POST["Type"]);
  $unit    = trim($_POST["unit"]);
  
// prepare sql and bind parameters
     $stmt = $dbconn->prepare("UPDATE item set name = :item_name, type = :type, unit = :unit where id = :id");
    $stmt->bindParam(':item_name', $item_name);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':unit', $unit);
    $stmt->bindParam(':id', $id);
   
    // insert a row
    if($stmt->execute()){
      $result =1;
    }
    echo $result;
    $dbconn = null;