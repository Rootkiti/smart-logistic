<?php
include_once('dbconn.php');
if(isset($_POST['action']))
{
    if($_POST['action'] == "save")
    {

        
  $product  = trim($_POST["product"]);
  $Type = trim($_POST["Type"]);
  $unit = trim($_POST["unit"]);

// prepare sql and bind parameters
    $stmt = $dbconn->prepare("INSERT INTO item(name, type, unit)
                               VALUES (:product, :Type, :unit)");
    $stmt->bindParam(':product', $product);
    $stmt->bindParam(':Type', $Type);
    $stmt->bindParam(':unit', $unit);
    

    // insert a row
    if($stmt->execute()){
      $result =1;
    }

        $result = 1;
        echo $result;
       $dbconn = null; 
    }



}
?>

