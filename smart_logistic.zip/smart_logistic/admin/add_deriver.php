<?php
include_once('dbconn.php');
if(isset($_POST['action']))
{
    if($_POST['action'] == "save")
    {

        
  $names  = trim($_POST["names"]);
  $category = trim($_POST["category"]);

// prepare sql and bind parameters
    $stmt = $dbconn->prepare("INSERT INTO derivers(names, category)
                               VALUES (:names, :category)");
    $stmt->bindParam(':names', $names);
    $stmt->bindParam(':category', $category);
    

    // insert a row
    if($stmt->execute()){
      $result =1;
    }

        echo $result;
       $dbconn = null; 
    }



}
?>

