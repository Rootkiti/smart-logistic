<?php
        include('dbconn.php');
        if(@$_GET['ids'] != '')
        {
            $ids = $_GET['ids'];
            $ids = implode(',',$ids);

            $reverse_type = $dbconn->prepare("SELECT Item_name, quantity_requested from request_items where id in ($ids)");
            $reverse_type->execute();
            $typs = $reverse_type->fetchAll();
            foreach($typs as $typ)
            {
                $type = $typ['Item_name'];
                $quantity_query = $dbconn->prepare("SELECT quantity from hq_stock where item = :type");
                $quantity_query->bindParam(':type',$type);
                 $quantity_query->execute();
                 $quant =$quantity_query->fetchColumn();
                if($quant > 0)
                {
                  $updated_quantity = $quant + $typ['quantity_requested'];
                  $update_query = $dbconn->prepare("UPDATE hq_stock set quantity = :updated_quantity where item = :type");
                  $update_query->bindParam(':updated_quantity', $updated_quantity);
                  $update_query->bindParam(':type', $type);

                  if($update_query ->execute())
                  {
                    $reverse_request = $dbconn->prepare("UPDATE request_items set status = 0 where id in ($ids)");
                    if($reverse_request ->execute())
                      {
                        echo("<script>document.location='requested_items.php';</script>");
                
                      }

                  }
                }
            }


        }
        else
        {
            echo("<script>document.location='requested_items.php';</script>");
        }
       
        

?>