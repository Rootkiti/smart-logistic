<?php session_start();
include_once('../dbconn.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
?>

<!DOCTYPE html>
<html>
<head>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Requested Items| Smart loigistic management information system</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

    
<style>
.container{
  margin: 20px auto;
}
h2 {
  text-align: center;
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}

body{
  font-family:Arial, Helvetica, sans-serif;
  font-size:13px;
}
.success, .error{
  border: 1px solid;
  margin: 10px 0px;
  padding:15px 10px 15px 50px;
  background-repeat: no-repeat;
  background-position: 10px center;
}

.success {
  color: #4F8A10;
  background-color: #DFF2BF;
  background-image:url('success.png');
  display: none;
}
.error {
  display: none;
  color: #D8000C;
  background-color: #FFBABA;
  background-image: url('error.png');
}
</style>
</head>
<body  class="sb-nav-fixed">
<?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
  <div class="container">
    
    <div class="success"></div>
    <div class="error"></div>
    <h2> Requested items</h2>
    
    
    
   <!-- data table start -->
  <form action="items_send.php" method="post">
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Pending Request
                               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                               
                    <button type="submit" name="items" class="btn btn-primary" style="margin-left: 500px;" title="send items">Approve</button>

                </div>
                </h3>
              </div>
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                
      <thead>
      <tr>
        <th>#</th>
        <th>Requested Items</th>
        <th>Type</th>
        <th>Requested Quantity</th>
        <th>Requested By</th>
        <th>Action</th>
      </tr>
      </thead>
      <tbody>
  <?php
  /* FetchAll foreach with edit and delete using Ajax */
  
$sth = $dbconn->prepare("SELECT request_items.id as id,request_items.quantity_requested as quantity,request_items.type as type,
                          item.name as item,  item.unit as unit, prison.name as requested 
                         FROM request_items, item, prison where request_items.status = 0 and item.id=request_items.Item_name
                         and prison.id=request_items.requested_by order by request_items.requested_by asc");
$sth->execute();
/* Fetch all of rows in the result set */
$result = $sth->fetchAll();
  if($sth->rowCount()):
    $cts = 1;
   foreach($result as $row){ ?>
     <tr>
       <td><?php echo $cts; ?></td>
       <td><?php echo $row['item']; ?></td>
       <td><?php echo $row['type']; ?></td>
       <td><?php echo $row['quantity']; ?> <span><?php echo $row['unit']; ?></span></td>
       <td><?php echo $row['requested']; ?></td>

       <td><input type="checkbox" value="<?=$row['id'];?>" name="items_send[]" id="" title="Approve request" >
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a class='delbtn' data-pid=<?php echo $row['id']; ?> href='javascript:void(0)'>
                <li class="fa fa-trash" title="cancel request" ></li>
            </a>
        </td>
     </tr>
   <?php $cts ++;}  ?>
  <?php endif;  ?>
  </tbody>
  </table>
  
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            
          </div>
          <!-- /.col -->
          
        </div>
        <!-- /.row -->
        
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- data table end -->
  </form>
  </div>
        
  
  
</div>
</div>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <!-- jQuery -->
  <script src="../plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- DataTables  & ../Plugins -->
        <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="../plugins/jszip/jszip.min.js"></script>
        <script src="../plugins/pdfmake/pdfmake.min.js"></script>
        <script src="../plugins/pdfmake/vfs_fonts.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
        <!-- AdminLTE App -->
        <script src="../dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <!-- <script src="../dist/js/demo.js"></script> -->
        <!-- Page specific script -->
        <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
        </script>
  <script>
    $(function(){

      /* Delete button ajax call */
      $('.delbtn').on( 'click', function(){
        if(confirm('This Date will delete this request.')){
          var pid = $(this).data('pid');
          $.post( "delete_request.php", { pid: pid })
          .done(function( data ) {
            if(data > 0){
              $('.success').show(500).html("Request deleted successfully.").delay(500).fadeOut(6000);
            }else{
              $('.error').show(500).html("Request could not be deleted. Please try again.").delay(500).fadeOut(6000);;
            }
            setTimeout(function(){
                window.location.reload(1);
            }, 500);
          });
        }
      });

    });
 </script>
</body>
</html>
<?php } ?>