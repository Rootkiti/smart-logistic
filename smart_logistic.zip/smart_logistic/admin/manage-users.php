<?php session_start();
include_once('dbconn.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
// for diactivating user
if(isset($_GET['id']))
{
$adminid=$_GET['id'];
$msg=$dbconn->prepare("UPDATE prison_user SET status = 0 where id='$adminid'");
if($msg->execute())
{
echo "<script>alert('User Disactivated');document.location='manage-users.php';</script>";
}
}
// restoring the user
if(isset($_GET['uid']))
{
$uid=$_GET['uid'];
$msg=$dbconn->prepare("UPDATE prison_user SET status = 1 where id='$uid'");
if($msg->execute())
{
echo "<script>alert('User Activated');document.location='manage-users.php';</script>";
}
}

// deleting the user
if(isset($_GET['dltid']))
{
$dltid=$_GET['dltid'];
$msg=$dbconn->prepare("DELETE from prison_user where id='$dltid' and status = 0");
if($msg->execute())
{
echo "<script>alert('User Deleted');document.location='manage-users.php';</script>";
}
}
   ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Manage Users | Smart loigistic management information system</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
         <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Manage users</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Manage users</li>
                        </ol>
            
                       
    <!-- data table start -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                   Active User Details
                </div>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                            <th>Sno.</th>
                <th>First Name</th>
                <th> Last Name</th>
                <th> Email Id</th>
                <th>Contact no.</th>
                <th>Prison</th>
                <th>Action</th>
                    </tr>
                </thead>
            <tbody>
            <?php

                $prison_sql= 'SELECT prison_user.id as id, prison_user.fname as fname, prison_user.lname as lname, prison_user.email as email
                               , prison_user.contact as contact, prison.name as prison_name from prison_user, prison
                                where prison_user.status=1 and prison.id=prison_user.prison';
                $prison_stm = $dbconn->prepare($prison_sql);
                $prison_stm->execute();
                $prison_data =$prison_stm->fetchAll();
                $cnt = 1;
                foreach($prison_data as $row)
                {
            ?>
            <tr>
            <td><?php echo $cnt;?></td>
                <td><?php echo $row['fname'];?></td>
                <td><?php echo $row['lname'];?></td>
                <td><?php echo $row['email'];?></td>
                <td><?php echo $row['contact'];?></td>  
                <td><?php echo $row['prison_name'];?></td> 
                <td>
                    
                    <a href="user-profile.php?uid=<?php echo $row['id'];?>"> 
        <i class="fas fa-edit"></i></a>
                    <a href="manage-users.php?id=<?php echo $row['id'];?>" onClick="return confirm('Do you really want to Diactivate this user?');"><i class="fa fa-trash" aria-hidden="true" title="Disactivate the user"></i></a>
                </td>
            </tr>
            <?php $cnt=$cnt+1; }?>
                    
                </tbody>
                <tfoot>
                    <tr>
                        <th>Sno.</th>
            <th>First Name</th>
            <th> Last Name</th>
            <th> Email Id</th>
            <th>Contact no.</th>
            <th>Reg. Date</th>
            <th>Action</th>
                    </tr>
                </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <!-- trashed users -->
     <!-- Main content -->
    <center>
    <div style="margin-top: 30px; font: size 24px; font-weight: 800;">
      Disactivated users will appear here
    </div>
    </center>
     <section class="content" style="margin-top: 30px;">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Disaxtivated User Details
                </div>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                            <th>Sno.</th>
                <th>First Name</th>
                <th> Last Name</th>
                <th> Email Id</th>
                <th>Contact no.</th>
                <th>Prison</th>
                <th>Action</th>
                    </tr>
                </thead>
            <tbody>
            <?php

                $prison_sql= 'SELECT prison_user.id as id, prison_user.fname as fname, prison_user.lname as lname, prison_user.email as email
                               , prison_user.contact as contact, prison.name as prison_name from prison_user, prison
                                where prison_user.status=0 and prison.id=prison_user.prison';
                $prison_stm = $dbconn->prepare($prison_sql);
                $prison_stm->execute();
                $prison_data =$prison_stm->fetchAll();
                $cnt = 1;
                foreach($prison_data as $row)
                {
            ?>
            <tr>
            <td><?php echo $cnt;?></td>
                <td><?php echo $row['fname'];?></td>
                <td><?php echo $row['lname'];?></td>
                <td><?php echo $row['email'];?></td>
                <td><?php echo $row['contact'];?></td>  
                <td><?php echo $row['prison_name'];?></td> 
                <td>
                    
                    <a href="manage-users.php?uid=<?php echo $row['id'];?>"> 
        <i class="fas fa-recycle" title="Activate the user"></i></a>
                    <a href="manage-users.php?dltid=<?php echo $row['id'];?>" onClick="return confirm('Do you really want to delete');"><i class="fa fa-trash" aria-hidden="true" title="Delete the user"></i></a>
                </td>
            </tr>
            <?php $cnt=$cnt+1; }?>
                    
                </tbody>
                <tfoot>
                    <tr>
                        <th>Sno.</th>
            <th>First Name</th>
            <th> Last Name</th>
            <th> Email Id</th>
            <th>Contact no.</th>
            <th>Reg. Date</th>
            <th>Action</th>
                    </tr>
                </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- data table end -->
                    </div>
                </main>
  <?php include('../includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
        <!-- jQuery -->
        <script src="../plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- DataTables  & Plugins -->
        <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="../plugins/jszip/jszip.min.js"></script>
        <script src="../plugins/pdfmake/pdfmake.min.js"></script>
        <script src="../plugins/pdfmake/vfs_fonts.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
        <!-- AdminLTE App -->
        <script src="../dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <!-- <script src="../dist/js/demo.js"></script> -->
        <!-- Page specific script -->
        <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
        </script>
    </body>
</html>
<?php } ?>