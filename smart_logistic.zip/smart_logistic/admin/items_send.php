


<?php session_start();
include_once('../dbconn.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } 
  else{
    
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Items Sent </title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
        <link rel="stylesheet" href="../plugins/fontawesome-free/css/fontawesome.min.css">
        <link rel="stylesheet" href="../plugins/fontawesome-free/css/fontawesome.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>   
      <style>
         @media print{
            body *{
               visibility: hidden;
            }
            .print-container, .print-container *{
               visibility: visible;
            }
            .print-container{
               position: absolute;
               /* left:0px; */
               top: 0px;

            }
         }
      </style>
      </head>
    <body class="sb-nav-fixed">
   <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
   
<div style=" border-radius:20px;  margin-top:2%; margin-left:2%;">
<?php

include('dbconn.php');
 if(isset($_POST["items"]))
 {
     if(@$_POST['items_send'] != '')
     {
        $all_ids=$_POST['items_send'];
        $all_ids = implode(',',$all_ids);
      //   echo ($all_ids);
        $toname = $dbconn->prepare("SELECT requested_by from request_items where id in ($all_ids)");
        $toname->execute();
        $name= $toname->fetch();
        $prison_id = $name['requested_by'];

        //getting prison head names 
        $prison_head = $dbconn->prepare("SELECT fname,lname from prison_user where prison = $prison_id");
        $prison_head->execute();
        $waden_name= $prison_head->fetch();
        $names = $waden_name['fname']." ".$waden_name['lname'];

        //getting prison name
        $prison_name = $dbconn->prepare("SELECT name from prison where id = $prison_id");
        $prison_name->execute();
        $prison= $prison_name->fetch();
        $prsn_nm = $prison['name'];
      

// getting requested items
        $getdata = $dbconn->prepare("SELECT request_items.id as id, request_items.type as type, request_items.quantity_requested as quantity_requested,
                                     request_items.requested_by as requested_by, item.name as Item_name, item.unit as unit
                                     from item, request_items where request_items.id in ($all_ids) and
                                      item.id=request_items.Item_name");
      //   $getdata->bindParam(':all_ids',$all_ids);
        $getdata->execute();
        $data = $getdata->fetchAll();
        ?>
      <div class="print-container">

      <div>
      From : HQ <br>
      To : <?=$prsn_nm;?>
   </div>
  
        <table class="table table-striped">
           <thead>
              <th>#</th>
              <th>Item</th>
              <th>Type</th>
              <th>Quantity</th>

           </thead>
        <?php
        $cnt = 1;
        $request_ids;
        foreach($data as $row)
        
        {
         $typ=$row['type'];
        
         $quantity_validator = $dbconn->prepare("SELECT quantity from hq_stock where type=:typ");
         $quantity_validator->bindParam(':typ',$typ);
         $quantity_validator->execute();
         $quant = $quantity_validator->fetchColumn();
         if($quant >= $row['quantity_requested'])
         {
            if(@$request_ids == '')
            {
               @$request_ids= $row['id'];
            }
            else
            {
               @$request_ids .= ",".$row['id'];
            }
            $updated_quantity = $quant - $row['quantity_requested'];

            $update_query = $dbconn->prepare("UPDATE hq_stock set quantity = :updated_quantity where type = :typ");
            $update_query->bindParam(':updated_quantity', $updated_quantity);
            $update_query->bindParam(':typ', $typ);
            

            // verified requests
            if( $update_query ->execute())
            {
               $verified_request = $dbconn->prepare("UPDATE request_items set status = 1 where id in ($request_ids)");
               

               if($verified_request ->execute())
               {
                  ?>

                     <tr>
                        
                        <td><?=$cnt;?> </td>
                        <td><?=$row['Item_name'];?></td>
                        <td><?=$row['type'];?> </td>
                        <td><?=$row['quantity_requested'];?><span> <?=$row['unit'];?></span></td>
                        
                     </tr>
                     <?php
               }
              

               

           
            }

            

         
            
         }

        
         
           
           $cnt++;
        }
        ?>
        </table>
        <?php
     }
     else
     {
        echo ("<script>document.location ='requested_items.php';</script>");
     }
     ?>
     
     <div>
        <?php
        $deriver=$dbconn->prepare("SELECT names from derivers where status = 1");
        $deriver->execute();
        $derivers=$deriver->fetchAll();
       ?>
          Transported by: 
         
          <select name="" id=""  style="border: none;">
             <option value=""> ---------- <br></option>
           <?php
            foreach($derivers as $drv)
            {
               ?>
           <option value=""><?=$drv['names'];?></option>
      

      <?php
      }
        ?>
        </select><br>
        Requested by:  <?=$names;?>
     </div>
      </div>
      <div>
         <br>
         <button class="btn btn-primary" onclick="window.print();">print</button>
        <a href="reverse_transaction.php?ids[]=<?=$request_ids;?>"> <button class="btn btn-danger">Cancel</button></a>
      </div>

   <?php
 }
?>
</div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>