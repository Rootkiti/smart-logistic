<?php
include_once('dbconn.php');
if(isset($_POST['action']))
{
    if($_POST['action'] == "save")
    {

        
  $product  = trim($_POST["product"]);
  $Quantity = trim($_POST["Quantity"]);
  $Type = trim($_POST["Type"]);
  $date = trim($_POST["date"]);

  // prepare sql and bind parameters
  $product_stmt = $dbconn->prepare("SELECT quantity from hq_stock where item = :product");
  $product_stmt->bindParam(':product', $product);
  // fetch a row
  $product_stmt->execute();
  $product_data = $product_stmt->fetch(PDO::FETCH_ASSOC);

  if($product_data > 0)
  {
   $qunt = $product_data['quantity']; 
  

    $updated_quantity = $qunt + $Quantity;

    $update_stmt = $dbconn->prepare("UPDATE hq_stock set quantity = :updated_quantity where item = :product");
    $update_stmt->bindParam(':updated_quantity', $updated_quantity);
    $update_stmt->bindParam(':product', $product);
    // insert a row
    if($update_stmt->execute()){
      $result =1;
    }
    
    echo $result;
    $dbconn = null;
  }
else{
// // prepare sql and bind parameters for inserting unexisting product
    $stmt = $dbconn->prepare("INSERT INTO hq_stock(item, quantity, type,date)
                               VALUES (:product, :Quantity, :Type, :date)");
    $stmt->bindParam(':product', $product);
    $stmt->bindParam(':Quantity', $Quantity);
    $stmt->bindParam(':Type', $Type);
    $stmt->bindParam(':date', $date);

    // insert a row
    if($stmt->execute()){
      $result =1;
    }

        $result = 1;
        echo $result;
       $dbconn = null;
}

 
    }



}
?>

