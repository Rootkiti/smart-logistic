<?php
  require_once('dbconn.php');
  $id = trim($_POST["item_id"]);
  $item_name  = trim($_POST["product"]);
  $quantity    = trim($_POST["Quantity"]);
  $type    = trim($_POST["Type"]);
  $date    = trim($_POST["date"]);
// prepare sql and bind parameters
     $stmt = $dbconn->prepare("UPDATE hq_stock set item = :item_name, quantity = :quantity, type = :type, 
                               date = :date where id = :id");
    $stmt->bindParam(':item_name', $item_name);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':date', $date);
    $stmt->bindParam(':id', $id);
   
    // insert a row
    if($stmt->execute()){
      $result =1;
    }
    echo $result;
    $dbconn = null;