<?php

  require_once('dbconn.php');

  $prison  = trim($_POST["prison_name"]);
  $location    = trim($_POST["location"]);
  

// prepare sql and bind parameters
    $stmt = $dbconn->prepare("INSERT INTO prison (name, location) VALUES (:prison, :location)");
    $stmt->bindParam(':prison', $prison);
    $stmt->bindParam(':location', $location);
    
    // insert a row
    if($stmt->execute()){
      $result =1;
    }

    echo $result;
    $dbconn = null;
