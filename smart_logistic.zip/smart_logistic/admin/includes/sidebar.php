  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading"></div>
                            <a class="nav-link" href="dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link" href="add_prison.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-plus"></i></div>
                                Add Prison
                            </a>
                            <a class="nav-link" href="add_item.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-plus"></i></div>
                                Add Item Type
                            </a>
                            <a class="nav-link" href="add_derive.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-plus"></i></div>
                                Add Derive
                            </a>
                            <a class="nav-link" href="signup.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-plus"></i></div>
                                Add User
                            </a>
                             <a class="nav-link" href="manage-users.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                Manage Users
                            </a>
                             <a class="nav-link" href="requested_items.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-fax"></i></div>
                                Requested!
                            </a>

                            
                             <a class="nav-link" href="hq_inventory.php">
                                <div class="sb-nav-link-icon"><i class="far fa-Inventory"></i></div>
                                Inventory
                            </a>
                            
                 
                           

 <a class="nav-link" href="bwdates-report-ds.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-calendar"></i></div>
                                General Report
                            </a>

                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                                Signout
                            </a>
                        </div>
                    </div>
                
                </nav>
            </div>