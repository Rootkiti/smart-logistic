<?php
  require_once('dbconn.php');
  $id = trim($_POST["deriver_id"]);
  $names  = trim($_POST["names"]);
  $category    = trim($_POST["category"]);
  
// prepare sql and bind parameters
     $stmt = $dbconn->prepare("UPDATE derivers set names = :names, category = :category where id = :id");
    $stmt->bindParam(':names', $names);
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':id', $id);
   
    // insert a row
    if($stmt->execute()){
      $result =1;
    }
    echo $result;
    $dbconn = null;