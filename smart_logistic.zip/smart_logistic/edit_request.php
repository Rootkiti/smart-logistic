<?php

  require_once('dbconn.php');

  $request_id  = trim($_POST["request_id"]);
  $item_name = trim($_POST["item_name"]);
  $type = trim($_POST["type"]);
  $Quantity     = trim($_POST["Quantity"]);


// prepare sql and bind parameters
    $stmt = $dbconn->prepare("UPDATE request_items set Item_name=:item_name, type=:type, quantity_requested=:Quantity 
                               where id=:request_id");
    $stmt->bindParam(':item_name', $item_name);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':Quantity', $Quantity);
    $stmt->bindParam(':request_id', $request_id);
    // insert a row
    if($stmt->execute()){
      $result =1;
    }
    echo $result;
    $dbconn = null;
    ?>