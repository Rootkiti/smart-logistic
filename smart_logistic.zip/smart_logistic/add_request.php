<?php session_start();
include_once('dbconn.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{
    $user = $_SESSION['id'];
    $prison = $_SESSION['prison'];
?>

<!DOCTYPE html>
<html>
<head>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Send Request| Smart loigistic management information system</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

    
<style>
.container{
  margin: 20px auto;
}
h2 {
  text-align: center;
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}

body{
  font-family:Arial, Helvetica, sans-serif;
  font-size:13px;
}
.success, .error{
  border: 1px solid;
  margin: 10px 0px;
  padding:15px 10px 15px 50px;
  background-repeat: no-repeat;
  background-position: 10px center;
}

.success {
  color: #4F8A10;
  background-color: #DFF2BF;
  background-image:url('success.png');
  display: none;
}
.error {
  display: none;
  color: #D8000C;
  background-color: #FFBABA;
  background-image: url('error.png');
}
</style>
</head>
<body  class="sb-nav-fixed">
<?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
  <div class="container">
    
    <div class="success"></div>
    <div class="error"></div>
    <h2> Request items</h2>
    <form >
      <center>
      <table class="table table-bordered table-striped ">
        <tr>
          
         <input type="hidden"  id ="rqst_id" value='' />
         <input type="hidden"  id ="rqst_by" value='<?=$prison;?>' />
         <td  style="text-align: center" class="form-floating mb-3 mb-md-0">
          <select   id="Item_name"  class="form-control">
              <option value="#">      </option>
                    <?php
                    /* FetchAll foreach with edit and delete using Ajax */
                    $items = $dbconn->prepare("SELECT id, name FROM item  where status = 1 order by name asc");
                    $items->execute();
                  /* Fetch all of rows in the result set */
                  $results = $items->fetchAll();
                    
                    foreach($results as $row){ ?>
                    
                          
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                        

                    <?php }  ?>
                    
              </select>
            <!-- <input type='text' class="form-control" id='Item_name' placeholder='Item name' required /> -->
            <label for="inputPassword">Item name</label>
          </td>

          <td  style="text-align: center" class="form-floating mb-3 mb-md-0">
          <select   id="type"  class="form-control">
              <option value="">      </option>
                    <?php
                    /* FetchAll foreach with edit and delete using Ajax */
                    $items = $dbconn->prepare("SELECT type FROM item  where status = 1 order by name asc");
                    $items->execute();
                  /* Fetch all of rows in the result set */
                  $results = $items->fetchAll();
                    
                    foreach($results as $row){ ?>
                    
                          
                        <option value="<?php echo $row['type']; ?>"><?php echo $row['type']; ?></option>
                        

                    <?php }  ?>
                    
              </select>
            <!-- <input type='text' class="form-control" id='Item_name' placeholder='Item name' required /> -->
            <label for="inputPassword">Item Type</label>
          </td>
         
            <td style="text-align: center; height: 20px;" class="form-floating mb-3 mb-md-0">
                <input type='text' class="form-control" id='Quantity' placeholder='Quantity' 
                                 pattern="[0-9]" required />
                <label for="inputPassword">Quantity </label>
           </td>

           <td style="text-align: center; height: 20px;" class="form-floating mb-3 mb-md-0">
           <?php
                $userid=$_SESSION['id'];
                $query=$dbconn->prepare("SELECT prison_user.id as id, prison.name as name from prison_user, prison
                                          where prison_user.id= :userid and prison.id=prison_user.prison");
                $query->bindParam(':userid', $userid);
                $query->execute();
                $rst=$query->fetchAll();
                foreach($rst as $result){?>
                <input type='text' class="form-control"  value="<?php echo $result['name'];?>"
                        placeholder='Quantity' readonly />
                <input type="hidden" id='#' value="<?=$userid;?>">        
                <label for="inputPassword">Requested By </label>
                <?php }?>
           </td>
           
        <td style="text-align: center">
          <input type='button'  class="btn btn-primary " id='saverecords' title="Save" value ='Send Request' />
        </td>
        
        </tr>
      </table>
      </center>
    </form>
    
    
   <!-- data table start -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Pending Request
                </div>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                
      <thead>
      <tr>
        <th>#</th>
        <th>Requested Items</th>
        <th>Type</th>
        <th>Requested Quantity</th>
        <th>Action</th>
      </tr>
      </thead>
      <tbody>
  <?php
  /* FetchAll foreach with edit and delete using Ajax */
  
$sth = $dbconn->prepare("SELECT request_items.id as id,request_items.quantity_requested as quantity,
                         request_items.requested_by as requested, item.name as item, request_items.type as type, item.unit as unit  
                         FROM request_items, item where request_items.status = 0 and item.id=request_items.Item_name
                         and request_items.requested_by=$prison order by request_items.id asc");
$sth->execute();
/* Fetch all of rows in the result set */
$result = $sth->fetchAll();
  if($sth->rowCount()):
    $cts = 1;
   foreach($result as $row){ ?>
     <tr>
       <td><?php echo $cts; ?></td>
       <td><?php echo $row['item']; ?></td>
       <td><?php echo $row['type']; ?></td>
       <td><?php echo $row['quantity']; ?> <span><?php echo $row['unit']; ?></span></td>

       <td><a data-pid = <?php echo $row['id']; ?> class='editbtn' href= 'javascript:void(0)'>
                <li class="fas fa-edit" title="edit request"></li>
            </a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a class='delbtn' data-pid=<?php echo $row['id']; ?> href='javascript:void(0)'>
                <li class="fa fa-trash" title="cancel request" ></li>
            </a>
        </td>
     </tr>
   <?php $cts ++;}  ?>
  <?php endif;  ?>
  </tbody>
  </table>
  
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            
          </div>
          <!-- /.col -->
          
        </div>
        <!-- /.row -->
        
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- data table end -->
  </div>
        
  
  
</div>
</div>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- DataTables  & Plugins -->
        <script src="plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="plugins/jszip/jszip.min.js"></script>
        <script src="plugins/pdfmake/pdfmake.min.js"></script>
        <script src="plugins/pdfmake/vfs_fonts.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
        <!-- AdminLTE App -->
        <script src="dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <!-- <script src="../dist/js/demo.js"></script> -->
        <!-- Page specific script -->
        <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
        </script>
  <script>
    $(function(){

      /* Delete button ajax call */
      $('.delbtn').on( 'click', function(){
        if(confirm('This Date will delete this request.')){
          var pid = $(this).data('pid');
          $.post( "delete_request.php", { pid: pid })
          .done(function( data ) {
            if(data > 0){
              $('.success').show(500).html("Request deleted successfully.").delay(500).fadeOut(6000);
            }else{
              $('.error').show(500).html("Request could not be deleted. Please try again.").delay(500).fadeOut(6000);;
            }
            setTimeout(function(){
                window.location.reload(1);
            }, 500);
          });
        }
      });

     /* Edit button ajax call */
      $('.editbtn').on( 'click', function(){
          var pid = $(this).data('pid');
          $.get( "get_request_for_edit.php", { id: pid })
            .done(function( product ) {
              data = $.parseJSON(product);

              if(data){
                $('#rqst_id').val(data.id);
                $('#Item_name').val(data.Item_name);
                $('#type').val(data.type);
                $('#Quantity').val(data.quantity_requested)
                $("#saverecords").val('Save Changes');
            }
          });
      });

       /* Edit button ajax call */
       $('#saverecords').on( 'click', function(){
           var request_id  = $('#rqst_id').val();
           var requested_by  = $('#rqst_by').val();
           var item_name = $('#Item_name').val();
           var type = $('#type').val();
           var Quantity   = $('#Quantity').val();
           if(!item_name || !Quantity || !type ){
             $('.error').show(500).html("All fields are required.").delay(500).fadeOut(3000);
           }else{
                if(request_id){
                var url = 'edit_request.php';
              }else{
                var url = 'send_request.php';
              }
                $.post( url, {request_id:request_id, requested_by:requested_by, item_name:item_name, type:type, Quantity:Quantity})
               .done(function( data ) {
                 
                 $("#saverecords").val('Add Records');
                 setTimeout(function(){
                     window.location.reload(1);
                 }, 1000);
             });
          }
       });
    });
 </script>
</body>
</html>
<?php } ?>

