  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="welcome.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>

                            <a class="nav-link" href="add_department.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-plus"></i></div>
                                Add Department
                            </a>

                            <a class="nav-link" href="signup.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-plus"></i></div>
                                Add User
                            </a>

                            <a class="nav-link" href="manage-users.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                Manage Users
                            </a>
                            
                             <a class="nav-link" href="add_request.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-fax"></i></div>
                                Request Items
                            </a>

                              <a class="nav-link" href="inventory.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-Inventory"></i></div>
                                Inventory
                            </a>

                        </div>
                    </div>
                
                </nav>
            </div>