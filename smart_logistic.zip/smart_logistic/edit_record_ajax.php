<?php

  require_once('dbconn.php');

  $product  = trim($_POST["product"]);
  $owner  = trim($_POST["owner"]);
  $Quantity = trim($_POST["Quantity"]);
  $Type     = trim($_POST["Type"]);
  $e_date   = trim($_POST["date"]);
  $prod_id     = trim($_POST["prod_id"]);

// prepare sql and bind parameters
    $stmt = $dbconn->prepare("UPDATE invetory set Item_name=:product, Quantity=:Quantity, Type=:Type, e_date=:e_date, owner=:owner where id=:id");
    $stmt->bindParam(':product', $product);
    $stmt->bindParam(':Quantity', $Quantity);
    $stmt->bindParam(':Type', $Type);
    $stmt->bindParam(':e_date', $e_date);
    $stmt->bindParam(':owner', $owner);
    $stmt->bindParam(':id', $prod_id);
    // insert a row
    if($stmt->execute()){
      $result =1;
    }
    echo $result;
    $dbconn = null;
    ?>