<?php session_start();
include_once('includes/config.php');
require_once('dbconn.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } 


?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Manage Users | Smart loigistic management information system</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
        
<style>
.container{
  margin: 20px auto;
}
h2 {
  text-align: center;
}
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}

body{
  font-family:Arial, Helvetica, sans-serif;
  font-size:13px;
}
.success, .error{
  border: 1px solid;
  margin: 10px 0px;
  padding:15px 10px 15px 50px;
  background-repeat: no-repeat;
  background-position: 10px center;
}

.success {
  color: #4F8A10;
  background-color: #DFF2BF;
  background-image:url('success.png');
  display: none;
}
.error {
  display: none;
  color: #D8000C;
  background-color: #FFBABA;
  background-image: url('error.png');
}
</style>
</head>
<body class="sb-nav-fixed">
<?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
         <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
  <div class="container">
   
    <h2>Inventory smart logistic </h2>
    
    <div class="success"></div>
    <div class="error"></div>
    <h2>Add / Edit Records</h2>
    <form>
       <table class="table table-striped">
        <tr>
          <?php
          $uid = $_SESSION['id'];
          ?>
            <input type="hidden"  id ='prod_id' value='' />
            <input type="hidden"  id ='item_owner' value="<?=$uid;?>" />
         
          <td  style="text-align: center" class="form-floating mb-3 mb-md-0">
          <select   id="Item_name"  class="form-control">
              <option value="#">      </option>
                    <?php
                    /* FetchAll foreach with edit and delete using Ajax */
                    $items = $dbconn->prepare("SELECT id, name FROM item  where status = 1 order by name asc");
                    $items->execute();
                  /* Fetch all of rows in the result set */
                  $results = $items->fetchAll();
                    
                    foreach($results as $row){ ?>
                    
                          
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                        

                    <?php }  ?>
                    
              </select>
            <!-- <input type='text' class="form-control" id='Item_name' placeholder='Item name' required /> -->
            <label for="inputPassword">Item name</label>
          </td>
          <td  style="text-align: center" class="form-floating mb-3 mb-md-0">  
            <input type='text' class="form-control" id='Quantity' placeholder='Quantity' pattern="[0-9]" required />
            <label for="inputPassword">Quantity </label>
          </td>
          <td  style="text-align: center" class="form-floating mb-3 mb-md-0">
            <input type='text' class="form-control" id='Type' placeholder='Type' required />
            <label for="inputPassword">Type </label>
          </td>
          <td  style="text-align: center" class="form-floating mb-3 mb-md-0">  
             <input type='date' class="form-control" id='e_date' placeholder='Entry Date' required />
             <label for="inputPassword">Entry Date</label>
          </td>
          
          <td  style="text-align: center">
              <input type='button' class="btn btn-primary" id='saverecords'  value ='Add Records' />
          </td>
        </tr>
      </table>
    </form>
    <!-- data table start -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    View Records
                </div>
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
             <table id="example1" class="table table-bordered table-striped">
                
      <thead>
      <tr>
        <th>#</th>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Type</th>
        <th>Date</th>
        <th>Action</th>
      </tr>
      </thead>
      <tbody>
  <?php
  /* FetchAll foreach with edit and delete using Ajax */
  $user=$_SESSION['id'];
  $sth = $dbconn->prepare("SELECT invetory.id as id, invetory.Quantity as Quantity, invetory.Type as Type, 
                           invetory.e_date as e_date,  item.name as Item_name, 
                           item.unit as unit FROM invetory, item where item.id = invetory.Item_name and invetory.item_owner=$user  order by invetory.id desc");
$sth->execute();
/* Fetch all of rows in the result set */
$result = $sth->fetchAll();
  if($sth->rowCount()):
    $a = 1;
   foreach($result as $row){ ?>
   
          <tr>
       <td><?php echo $a ?></td>
       <td><?php echo $row['Item_name']; ?></td>
       <td><?php echo $row['Quantity']; ?> <span><?php echo $row['unit']; ?></span></td>
       <td><?php echo $row['Type']; ?></td>
       <td><?php echo $row['e_date']; ?></td>


       <td><a data-pid = <?php echo $row['id']; ?> class='editbtn' href= 'javascript:void(0)'><li class="fa fa-edit"></li></a>&nbsp;|&nbsp;<a class='delbtn' data-pid=<?php echo $row['id']; ?> href='javascript:void(0)'><li class="fa fa-trash"></li></a></td>
     </tr>
   <?php $a ++;}  ?>
  <?php endif;  ?>
  </tbody>

  </table>

  </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- data table end -->
  
  </div>
  
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- DataTables  & Plugins -->
        <script src="plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="plugins/jszip/jszip.min.js"></script>
        <script src="plugins/pdfmake/pdfmake.min.js"></script>
        <script src="plugins/pdfmake/vfs_fonts.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
        <!-- AdminLTE App -->
        <script src="dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <!-- <script src="dist/js/demo.js"></script> -->
        <!-- Page specific script -->
        <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
        </script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      $('nav li').on('click', function () {  // we are letting the li bind to the event
        alert('Do you Real want to Close the stock');
      });
    });
  </script>
  <script>
    $(function(){

      /* Delete button ajax call */
      $('.delbtn').on( 'click', function(){
        if(confirm('This Date will delete this record. Are you sure?')){
          var pid = $(this).data('pid');
          $.post( "delete_ajax.php", { pid: pid })
          .done(function( data ) {
            if(data > 0){
              $('.success').show(500).html("Record deleted successfully.").delay(500).fadeOut(6000);
            }else{
              $('.error').show(500).html("Record could not be deleted. Please try again.").delay(500).fadeOut(6000);;
            }
            setTimeout(function(){
                window.location.reload(1);
            }, 500);
          });
        }
      });

     /* Edit button ajax call */
      $('.editbtn').on( 'click', function(){
          var pid = $(this).data('pid');
          $.get( "getrecord_ajax.php", { id: pid })
            .done(function( product ) {
              data = $.parseJSON(product);

              if(data){
                $('#prod_id').val(data.id);
                $('#Item_name').val(data.Item_name);
                $('#Quantity').val(data.Quantity);
                $('#Type').val(data.Type);
                $('#e_date').val(data.e_date);
                $("#saverecords").val('Save Records');
            }
          });
      });

      /* Edit button ajax call */
       $('#saverecords').on( 'click', function(){
           var prod_id = $('#prod_id').val();
           var item_owner = $('#item_owner').val();
           var product = $('#Item_name').val();
           var Quantity = $('#Quantity').val();
           var Type = $('#Type').val();
           var date = $('#e_date').val();


           if(!product || !Quantity || !Type ||!date){
             $('.error').show(500).html("All fields are required.").delay(500).fadeOut(3000);
           }else{
                if(prod_id){
                var url = 'edit_record_ajax.php';
              }else{
                var url = 'add_records_ajax.php';
              }
                $.post( url, {prod_id:prod_id, item_owner: item_owner, product: product, Quantity: Quantity, Type: Type, date: date})
               .done(function( data ) {
                 if(data > 0){
                   $('.success').show(500).html("Record saved successfully.").delay(500).fadeOut(1000);
                 }else{
                   $('.error').show(500).html("Record could not be saved. Please try again.").delay(500).fadeOut(1000);
                 }
                 $("#saverecords").val('Add Records');
                 setTimeout(function(){
                     window.location.reload(1);
                 }, 500);
             });
          }
       });
    });
 </script>
</body>
</html>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>



